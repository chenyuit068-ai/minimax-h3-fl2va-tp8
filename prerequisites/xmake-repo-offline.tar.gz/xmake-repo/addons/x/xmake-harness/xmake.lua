package("xmake-harness")
    set_kind("addon")
    set_homepage("https://github.com/xmake-addons/xmake-harness")
    set_description("A generic AI agent harness framework and the `xmake ai` terminal assistant, with the first-class xmake build enhancement.")
    set_license("Apache-2.0")

    add_urls("https://github.com/xmake-addons/xmake-harness/archive/refs/tags/$(version).tar.gz",
             "https://github.com/xmake-addons/xmake-harness.git")
    add_versions("v1.0.0", "44a0b3369ed6d2fc4458b0741ebc264c3bfe62de6749200c3498944811212daa")
    add_versions("v1.0.1", "aefa5d431efc73ae946480cb7e61fa22a342dd1055c05120a4dac40f044550c9")
    add_versions("v1.0.2", "a22f6a2aad36dbfe2baf0d83a16ae46df551ab5c92a79d12ae57705449e817bf")
    add_versions("v1.0.3", "8c868e719fced4a098844b8d22b05ee3217c5b03a99c3e93a95aae553738302d")
    add_versions("v1.0.4", "dccea6db72729a47bcc81124907b1ec920437d3fd32e0efe1c24d697c7f8450b")
    add_versions("v1.0.5", "a01401dddf233be32dcb6867c1c4742dd2286491c5c0efa758b18243e6d3fab6")
    add_versions("v1.0.6", "c03dec3099be35f0f00177298f6fcb6ee6893e38a4affb3d2421468cbdc5cb2d")
    add_versions("v1.0.7", "73691fb0657b903437fd174d559ee461287be6f3a4871c8e4f1d7f4d662d06e8")
    add_versions("v1.0.8", "260f6cb86cde107a1d75063216163c07b5b281b65cd39168293ecb68efd31caf")
    add_versions("v1.0.9", "5c838560162743a178f3081df30092c4e532a2523656c8e3e9a81ac606b0e6ee")
    add_versions("v1.1.0", "d16eabc13aaa9e547f4987efb77efef9c1b42ee22b5bb5f06edcbe90adfad1c0")

    on_test(function (package)
        assert(package:has_addon({plugins = "ai", modules = "harness"}))

        -- @note we only show the menu here, the agent needs an api key and the network
        os.vrun("xmake ai --help")
    end)
