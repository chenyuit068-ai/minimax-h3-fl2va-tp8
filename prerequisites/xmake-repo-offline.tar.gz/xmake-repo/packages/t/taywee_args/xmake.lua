package("taywee_args")

    set_kind("library", {headeronly = true})
    set_homepage("https://taywee.github.io/args/")
    set_description("A simple header-only C++ argument parser library.")
    set_license("MIT")

    add_urls("https://github.com/Taywee/args/archive/refs/tags/$(version).tar.gz",
             "https://github.com/Taywee/args.git")
    add_versions("6.6.0", "9949b763e4b43ad3362d5da365e7f6118df296bc29c1d2dff415baac1e430c43")
    add_versions("6.4.16", "13fd2c21c4941672f02d67ac666fe6507fe2c2e0f17f95a0c2f17fddb4023000")
    add_versions("6.4.8", "52ecaceb92c3865c8a210091f288b4902e0a08280327a80c4b8d8aec5d7a3bbe")
    add_versions("6.4.7", "ae53d120609ecf44ff079b6992b4b54d6c25e9d647d06f46d9f68fe1476c0454")
    add_versions("6.3.0", "e072c4a9d6990872b0ecb45480a5487db82e0dc3d27c3c3eb9fc0930c0d796ae")
    add_versions("6.4.6", "41ed136bf9b216bf5f18b1de2a8d22a870381657e8427d6621918520b6e2239c")

    on_install(function (package)
        os.cp("args.hxx", package:installdir("include"))
    end)

    on_test(function (package)
        assert(package:check_cxxsnippets({test = [[
            void test(int argc, char** argv) {
                args::ArgumentParser parser("This is a test program.", "This goes after the options.");
                args::HelpFlag help(parser, "help", "Display this help menu", {'h', "help"});
                args::CompletionFlag completion(parser, {"complete"});
                parser.ParseCLI(argc, argv);
            }
        ]]}, {configs = {languages = "c++11"}, includes = "args.hxx"}))
    end)
