import contextlib

with contextlib.suppress(ImportError):
    from ._preload import preload

    preload()

import infinicore.context as context
import infinicore.nn as nn
from infinicore._tensor_str import printoptions, set_printoptions

# Import context functions
from infinicore.context import (
    get_device,
    get_device_count,
    get_stream,
    is_graph_recording,
    set_device,
    start_graph_recording,
    stop_graph_recording,
    sync_device,
    sync_stream,
)
from infinicore.device import device
from infinicore.device_event import DeviceEvent
from infinicore.dtype import (
    bfloat16,
    bool,
    cdouble,
    cfloat,
    chalf,
    complex32,
    complex64,
    complex128,
    double,
    dtype,
    float,
    float8,
    float16,
    float32,
    float64,
    half,
    int,
    int8,
    int16,
    int32,
    int64,
    long,
    short,
    uint8,
)
from infinicore.ops.acos import acos
from infinicore.ops.add import add
from infinicore.ops.add_rms_norm import add_rms_norm, add_rms_norm_inplace
from infinicore.ops.addbmm import addbmm
from infinicore.ops.addcmul import addcmul
from infinicore.ops.addr import addr
from infinicore.ops.all import all
from infinicore.ops.argwhere import argwhere
from infinicore.ops.ascend_flash_attn import (
    ascend_flash_attn_decode,
    ascend_flash_attn_prefill,
)
from infinicore.ops.asin import asin
from infinicore.ops.asinh import asinh
from infinicore.ops.asum import asum
from infinicore.ops.atanh import atanh
from infinicore.ops.attention import attention
from infinicore.ops.axpy import axpy
from infinicore.ops.baddbmm import baddbmm
from infinicore.ops.bilinear import bilinear
from infinicore.ops.binary_cross_entropy_with_logits import (
    binary_cross_entropy_with_logits,
)
from infinicore.ops.bitwise_right_shift import bitwise_right_shift
from infinicore.ops.blas_amax import blas_amax
from infinicore.ops.blas_amin import blas_amin
from infinicore.ops.blas_copy import blas_copy
from infinicore.ops.blas_dot import blas_dot
from infinicore.ops.block_diag import block_diag
from infinicore.ops.bmm_strided import bmm_strided
from infinicore.ops.broadcast_to import broadcast_to
from infinicore.ops.cast import cast
from infinicore.ops.cat import cat
from infinicore.ops.cdist import cdist
from infinicore.ops.concat_and_cache_mla import concat_and_cache_mla
from infinicore.ops.concat_and_cache_mla_int8 import concat_and_cache_mla_int8
from infinicore.ops.concat_mla_q import concat_mla_q
from infinicore.ops.conv2d import conv2d
from infinicore.ops.cross_entropy import cross_entropy
from infinicore.ops.diff import diff
from infinicore.ops.digamma import digamma
from infinicore.ops.dist import dist
from infinicore.ops.dsa import (
    compute_block_sparse_mqa_logits_,
    fused_deepseek_v2_indexer_postprocess_,
    indexer_k_cache_,
    map_decode_request_block_indices_,
    map_prefill_request_block_indices_,
    select_decode_topk_block_indices_,
    select_prefill_topk_block_indices_,
    sparse_flash_mla_,
    topk_indices_context_lens_,
)
from infinicore.ops.dynamic_scaled_int8_quant import dynamic_scaled_int8_quant
from infinicore.ops.equal import equal
from infinicore.ops.flipud import flipud
from infinicore.ops.float_power import float_power
from infinicore.ops.floor import floor
from infinicore.ops.floor_divide import floor_divide
from infinicore.ops.fmin import fmin
from infinicore.ops.fmod import fmod
from infinicore.ops.fused_rotary_embedding import fused_rotary_embedding_
from infinicore.ops.grouped_topk_vendor import grouped_topk_vendor
from infinicore.ops.hypot import hypot
from infinicore.ops.index_add import index_add
from infinicore.ops.index_copy import index_copy
from infinicore.ops.inner import inner
from infinicore.ops.kron import kron
from infinicore.ops.kthvalue import kthvalue
from infinicore.ops.kv_caching import kv_caching
from infinicore.ops.ldexp import ldexp
from infinicore.ops.lerp import lerp
from infinicore.ops.logaddexp import logaddexp
from infinicore.ops.logaddexp2 import logaddexp2
from infinicore.ops.logcumsumexp import logcumsumexp
from infinicore.ops.logdet import logdet
from infinicore.ops.logical_and import logical_and
from infinicore.ops.logical_not import logical_not
from infinicore.ops.masked_select import masked_select
from infinicore.ops.matmul import matmul
from infinicore.ops.mha import mha
from infinicore.ops.mha_kvcache import mha_kvcache
from infinicore.ops.mha_varlen import mha_varlen
from infinicore.ops.moe_argsort_bincount import moe_argsort_bincount_with_inv_pos_
from infinicore.ops.moe_expand_input import moe_expand_input_with_inv_pos_
from infinicore.ops.moe_silu_and_mul_quant import moe_silu_and_mul_quant_
from infinicore.ops.moe_sum_vendor import moe_sum_vendor_
from infinicore.ops.moe_topk_vendor import (
    moe_topk_sigmoid_vendor,
    moe_topk_softmax_vendor,
)
from infinicore.ops.moore_mate_flash_attn import (
    moore_mate_flash_attn_decode,
    moore_mate_flash_attn_prefill,
)
from infinicore.ops.mrope import mrope
from infinicore.ops.mul import mul
from infinicore.ops.mul_scalar import mul_scalar
from infinicore.ops.narrow import narrow
from infinicore.ops.nrm2 import nrm2
from infinicore.ops.paged_attention import paged_attention
from infinicore.ops.paged_attention_mla import paged_attention_mla_
from infinicore.ops.paged_attention_prefill import paged_attention_prefill
from infinicore.ops.paged_caching import paged_caching
from infinicore.ops.rearrange import rearrange
from infinicore.ops.reciprocal import reciprocal
from infinicore.ops.rot import rot
from infinicore.ops.rotg import rotg
from infinicore.ops.rotm import rotm
from infinicore.ops.rotmg import rotmg
from infinicore.ops.scal import scal
from infinicore.ops.scaled_mm_w4a8 import scaled_mm_w4a8
from infinicore.ops.scaled_mm_w8a8 import scaled_mm_w8a8
from infinicore.ops.scatter import scatter
from infinicore.ops.sinh import sinh
from infinicore.ops.situ_and_mul import situ_and_mul
from infinicore.ops.squeeze import squeeze
from infinicore.ops.sum import sum
from infinicore.ops.swap import swap
from infinicore.ops.take import take
from infinicore.ops.tan import tan
from infinicore.ops.timestep_embedding import timestep_embedding
from infinicore.ops.topk import topk
from infinicore.ops.unsqueeze import unsqueeze
from infinicore.ops.vander import vander
from infinicore.ops.var import var
from infinicore.ops.var_mean import var_mean
from infinicore.ops.vocab_parallel_embedding import vocab_parallel_embedding
from infinicore.ops.w4a8_group_gemm import w4a8_group_gemm_
from infinicore.ops.w8a8_group_gemm import w8a8_group_gemm_
from infinicore.ops.w16a16_group_gemm import w16a16_group_gemm_
from infinicore.tensor import (
    Tensor,
    empty,
    empty_like,
    from_blob,
    from_list,
    from_list_by_numpy,
    from_numpy,
    from_torch,
    ones,
    strided_empty,
    strided_from_blob,
    zeros,
)

__all__ = [
    # Modules.
    "context",
    "nn",
    # Classes.
    "device",
    "DeviceEvent",
    "dtype",
    "Tensor",
    # Context functions.
    "get_device",
    "get_device_count",
    "get_stream",
    "set_device",
    "sync_device",
    "sync_stream",
    "is_graph_recording",
    "start_graph_recording",
    "stop_graph_recording",
    # Data Types.
    "bfloat16",
    "bool",
    "cdouble",
    "cfloat",
    "chalf",
    "complex32",
    "complex64",
    "complex128",
    "double",
    "float",
    "float8",
    "float16",
    "float32",
    "float64",
    "half",
    "int",
    "int8",
    "int16",
    "int32",
    "int64",
    "long",
    "short",
    "uint8",
    # Operations.
    "addcmul",
    "atanh",
    "binary_cross_entropy_with_logits",
    "cdist",
    "reciprocal",
    "add",
    "addr",
    "add_rms_norm",
    "argwhere",
    "asin",
    "asum",
    "axpy",
    "blas_amax",
    "blas_amin",
    "blas_copy",
    "blas_dot",
    "acos",
    "addbmm",
    "floor",
    "attention",
    "mrope",
    "block_diag",
    "bmm_strided",
    "kron",
    "bitwise_right_shift",
    "kv_caching",
    "asinh",
    "baddbmm",
    "bilinear",
    "fmod",
    "cast",
    "cat",
    "conv2d",
    "inner",
    "masked_select",
    "logaddexp",
    "logaddexp2",
    "matmul",
    "equal",
    "mul",
    "mul_scalar",
    "situ_and_mul",
    "timestep_embedding",
    "diff",
    "digamma",
    "dist",
    "logdet",
    "narrow",
    "nrm2",
    "ldexp",
    "lerp",
    "kthvalue",
    "squeeze",
    "unsqueeze",
    "rearrange",
    "cross_entropy",
    "tan",
    "empty",
    "empty_like",
    "from_blob",
    "from_list",
    "from_list_by_numpy",
    "from_numpy",
    "from_torch",
    "mha_kvcache",
    "mha_varlen",
    "mha",
    "fmin",
    "floor_divide",
    "float_power",
    "flipud",
    "scatter",
    "rot",
    "rotg",
    "rotm",
    "rotmg",
    "scal",
    "logcumsumexp",
    "logical_not",
    "logical_and",
    "vander",
    "vocab_parallel_embedding",
    "paged_caching",
    "paged_attention",
    "paged_attention_prefill",
    "hypot",
    "index_copy",
    "index_add",
    "take",
    "sinh",
    "swap",
    "ones",
    "broadcast_to",
    "strided_empty",
    "strided_from_blob",
    "zeros",
    "sum",
    "var_mean",
    "moore_mate_flash_attn_prefill",
    "moore_mate_flash_attn_decode",
    "ascend_flash_attn_prefill",
    "ascend_flash_attn_decode",
    "var",
    "topk",
    "all",
    "set_printoptions",
    "printoptions",
]

use_ntops = False

with contextlib.suppress(ImportError, ModuleNotFoundError):
    import sys

    import ntops

    for op_name in ntops.torch.__all__:
        getattr(ntops.torch, op_name).__globals__["torch"] = sys.modules[__name__]

    use_ntops = True

__all__ += [
    "add_rms_norm_inplace",
    "concat_and_cache_mla",
    "concat_and_cache_mla_int8",
    "concat_mla_q",
    "compute_block_sparse_mqa_logits_",
    "fused_deepseek_v2_indexer_postprocess_",
    "indexer_k_cache_",
    "map_decode_request_block_indices_",
    "map_prefill_request_block_indices_",
    "select_decode_topk_block_indices_",
    "select_prefill_topk_block_indices_",
    "sparse_flash_mla_",
    "topk_indices_context_lens_",
    "dynamic_scaled_int8_quant",
    "fused_rotary_embedding_",
    "grouped_topk_vendor",
    "moe_argsort_bincount_with_inv_pos_",
    "moe_expand_input_with_inv_pos_",
    "moe_silu_and_mul_quant_",
    "moe_sum_vendor_",
    "moe_topk_sigmoid_vendor",
    "moe_topk_softmax_vendor",
    "paged_attention_mla_",
    "scaled_mm_w4a8",
    "scaled_mm_w8a8",
    "w16a16_group_gemm_",
    "w4a8_group_gemm_",
    "w8a8_group_gemm_",
]
